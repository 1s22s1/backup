---
title: "kaminariで発行するSQLクエリについて"
emoji: "📝"
type: "tech"
topics: []
published: true
published_at: "2023-09-19 16:06"
---

## 概要

kaminariで発行するSQLクエリについて確認する。

## 1ページ目を表示する

```ruby
Book.page(1).per(10)
```

```sql
SELECT
    "books".*
FROM
    "books"
LIMIT
    10
OFFSET
    0
```

## 2ページ目を表示する

```ruby
Book.page(2).per(10)
```

```sql
SELECT
    "books".*
FROM
    "books"
LIMIT
    10
OFFSET
    10
```

## 最後に

`OFFSET`でクライアントへ返す行の開始位置を読み飛ばしています。以上です。