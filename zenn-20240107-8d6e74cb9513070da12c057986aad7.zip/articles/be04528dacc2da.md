---
title: "Julia言語の配列において条件を満たす行を削除する"
emoji: "🚀"
type: "tech"
topics:
  - "julia"
published: true
published_at: "2023-12-28 16:36"
---

## 概要

Julia言語の配列において条件を満たす行を削除する方法を記載する。

## 参考コード

```julia
data = [
    [1, 0, 0],
    [0, 0, 0],
    [0, 1, 0],
    [0, 0, 0],
    [0, 0, 0],
    [0, 0, 1]
]

filtered_data = [line for line in data if !all(n -> n == 0, line)]

@show filtered_data # filtered_data = [[1, 0, 0], [0, 1, 0], [0, 0, 1]]
```