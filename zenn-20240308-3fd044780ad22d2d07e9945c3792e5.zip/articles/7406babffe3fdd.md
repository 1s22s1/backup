---
title: "0から999までの数字と0埋め3桁の数字に一致する正規表現について"
emoji: "🐥"
type: "tech"
topics:
  - "正規表現"
published: true
published_at: "2023-04-15 13:05"
---

0から999までの数字と0埋め3桁の数字に一致する正規表現をJulia言語で書いてみました。

## 書いてみた

```julia
# 退屈をかくも素直に愛しゐし日々は還らずさよなら京都／栗木京

module TestMatch
using Test

function main()
    @testset "10進数の0から999までの数字" begin
        reg_exp = r"^(\d{1}|[1-9]{1}\d{1}|[1-9]{1}\d{2})$"

        @test match(reg_exp, "0").match == "0"
        @test match(reg_exp, "000") === nothing
        @test match(reg_exp, "10").match == "10"
        @test match(reg_exp, "010") === nothing
        @test match(reg_exp, "100").match == "100"
        @test match(reg_exp, "999").match == "999"
    end

    @testset "10進数の0埋め3桁の数字" begin
        reg_exp = r"^\d{3}$"

        @test match(reg_exp, "0") === nothing
        @test match(reg_exp, "000").match == "000"
        @test match(reg_exp, "10") === nothing
        @test match(reg_exp, "010").match == "010"
        @test match(reg_exp, "100").match == "100"
        @test match(reg_exp, "999").match == "999"
    end
end
end

if abspath(PROGRAM_FILE) == @__FILE__
    using .TestMatch

    TestMatch.main()
end
```

## 感想

２、３週間前には、ほとんど正規表現を分かっていなかったのですが。。。まぁまぁ分かるようになって良かったです。