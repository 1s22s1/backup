---
title: "競プロのための算数・数学 039 問"
emoji: "🐷"
type: "idea"
topics:
  - "競プロのための算数・数学"
published: true
published_at: "2024-02-14 06:44"
---

## 問題

https://twitter.com/drken1215/status/1755993842233610644

## 解答

60段

## 解説

題意より、エスカレーターの上から最上階までは１００−４０＝６０で、６０段あることが分かる。