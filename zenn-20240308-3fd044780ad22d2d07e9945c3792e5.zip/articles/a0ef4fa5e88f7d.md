---
title: "競プロのための算数・数学 041 問"
emoji: "📌"
type: "tech"
topics:
  - "競プロのための算数・数学"
published: true
published_at: "2024-02-13 12:48"
---

## 問題

https://twitter.com/drken1215/status/1756879916342317351

## 答え

26通り

## 解説

ツルの足が２本なので０から５０、カメの足が４本なので０から２５の範囲で全探索する。

```julia
outcome = 0

for i ∈ 0:50, j ∈ 0:25
    if i*2 + j*4 == 100
        global outcome += 1
    end
end

println(outcome)
```