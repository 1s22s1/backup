---
title: "graphql-clientからGitHub GraphQL APIを呼び出す方法"
emoji: "💨"
type: "tech"
topics:
  - "graphql"
published: true
published_at: "2023-11-06 09:53"
---

## 概要

graphql-clientからGitHub GraphQL APIを呼び出す方法を記載します。

## 方法
### Fine-grained personal access tokensを取得する

https://github.com/settings/tokens?type=beta を開き、次の設定をする。

- Repository access: All repositories
- Contents: Read-only

### 呼び出す

自身のプライベートリポジトリのみを取得します。

```ruby
require "graphql/client"
require "graphql/client/http"

module GitHub
  http = GraphQL::Client::HTTP.new('https://api.github.com/graphql') do
    def headers(context)
      {'Authorization': "bearer github_pat_nagumo" }
    end
  end

  Client = GraphQL::Client.new(schema: GraphQL::Client.load_schema(http), execute: http)
end

SearchRepositoriesQuery = GitHub::Client.parse <<-'GRAPHQL'
{
  search(query: "owner:1s22s1 is:private", type: REPOSITORY, first: 3) {
    edges {
      node {
        ... on Repository {
          nameWithOwner
        }
      }
    }
  }
}
GRAPHQL

result = GitHub::Client.query(SearchRepositoriesQuery)

pp result.to_h
```

実行結果は、次の通りです。

```console
russ@penguin:~/src$ ruby client.rb 
{"data"=>
  {"search"=>
    {"edges"=>
      [{"node"=>{"__typename"=>"Repository", "nameWithOwner"=>"1s22s1/doguu"}}, {"node"=>{"__typename"=>"Repository", "nameWithOwner"=>"1s22s1/back_up_202310"}}]}}}
```

### 環境

- Ruby: 3.2.2
- graphql: 2.0.27
- graphql-client: 0.18.0