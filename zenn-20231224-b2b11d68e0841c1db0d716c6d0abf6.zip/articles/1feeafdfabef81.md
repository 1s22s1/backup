---
title: "GraphQL Inspectorを利用して、偽サーバーをたてる方法"
emoji: "💬"
type: "tech"
topics: []
published: true
published_at: "2023-08-23 13:18"
---

## 概要

GraphQL Inspectorを利用して、偽サーバーをたてる方法を記載します。

## 事前準備

GraphQL Inspectorをインストールします。

```console
yarn global add @graphql-inspector/cli graphql
```

## 偽サーバーを立ち上げる

最初にschema.graphqlsを準備します。

```graphql
type Query {
  book: Book!
}

type Book {
  id: ID!
  title: String!
  author: String!
}
```

次に偽サーバーを立ち上げます。

```console
graphql-inspector serve schema.graphqls
```

## GraphQLのクエリを発行する

```graphql
query GetBook {
  book {
    id
    title
    author
  }
}
```

以下は、レスポンスになります。

```json
{
  "data": {
    "book": {
      "id": "MC5kNDBlNGI4NDU1MmNj",
      "title": "Hello World",
      "author": "Hello World"
    }
  }
}
```

## 参考

- https://the-guild.dev/graphql/inspector/docs/commands/serve